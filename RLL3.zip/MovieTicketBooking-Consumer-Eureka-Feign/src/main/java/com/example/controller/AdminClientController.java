package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Admin;
import com.example.model.Login;
import com.example.proxy.AdminServiceProxy;
import com.example.proxy.LoginServiceProxy;


@RestController
@Scope("request")
public class AdminClientController {
      
	@Autowired
	private AdminServiceProxy adminserviceproxy;

	

	@GetMapping("/get-all/{adminId}")
	public Admin getAdminById(@PathVariable("adminId") long id) {
		Admin admin = adminserviceproxy.getAdminById(id);
		return admin;
	}
	
	@GetMapping("/get-all")
	public List<Admin> getAllAdmins() {
		List<Admin> admins = adminserviceproxy.getAllAdmins();
		return admins;
	}
	
//	@GetMapping("/get-all-login-users")
//	public List<Login> getAllUsers() {
//		List<Login> login = adminserviceproxy.getAllUsers();
//		return login;
//	}
}
