package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Cart;
import com.example.proxy.CartServiceProxy;

@RestController
@RequestMapping("/carts")
public class CartClientController {
	
	  
		@Autowired
		private CartServiceProxy cartserviceproxy;
		
//		@GetMapping("/get-viewAllCarts")
//		public List<Cart> getCartItems() {
//			List<Cart> carts = cartserviceproxy.getCartItems();
//			return carts;
//		}
		
		@GetMapping("/viewAllCarts")
	    public ResponseEntity<List<Cart>> getCartItems() {
	        List<Cart> cartItems = cartserviceproxy.getCartItems();
	        if (cartItems != null && !cartItems.isEmpty()) {
	            return ResponseEntity.status(HttpStatus.OK).body(cartItems);
	        } else {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	        }
	    }
		

}
