package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Customer;
import com.example.proxy.CustomerServiceProxy;

@RestController
public class CustomerClientController {
        
	@Autowired
	private CustomerServiceProxy customerserviceproxy;
	

	@GetMapping("/get-viewAll/{searchKeyword}")
	public List<Customer> viewAllCustomersBySearchKeyword(@PathVariable("searchKeyword") String searchKeyword) {
		List<Customer> admin = customerserviceproxy.viewAllCustomersBySearchKeyword(searchKeyword);
		return admin;
	}
	
	@GetMapping("/get-viewAll")
	public List<Customer> viewAllCustomers() {
		List<Customer> customers = customerserviceproxy.viewAllCustomers();
		return customers;
	}
}
