package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Login;
import com.example.proxy.LoginServiceProxy;

@RestController
@Scope("request")
public class LoginClientController {
       
	
	@Autowired
	private LoginServiceProxy loginserviceproxy;
	
	@GetMapping("/get-allusers")
	public List<Login> getAllUsers() {
		List<Login> login = loginserviceproxy.getAllUsers();
		return login;
	}
	
}
