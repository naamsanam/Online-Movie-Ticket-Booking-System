package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Admin;
import com.example.model.Movie;
import com.example.proxy.MovieServiceProxy;


@RestController
@Scope("request")
public class MovieClientController {
      
	
	@Autowired
	private MovieServiceProxy movieserviceproxy;
	
	@GetMapping("/get-allMovies")
    public List<Movie> getAllMovies(){
		List<Movie> movies =  movieserviceproxy.getAllMovies();
		return movies;
	}

    
    @GetMapping("/get-allMovies/{id}")
	public Movie getMovieById(@PathVariable("id") long id) {
		Movie movie = movieserviceproxy.getMovieById(id);
		return movie;
    }

}
