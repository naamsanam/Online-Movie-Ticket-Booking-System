package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Ordered;
import com.example.proxy.OrderedServiceProxy;

@RestController
@Scope("request")
public class OrderedClientController {
      
	@Autowired
	private OrderedServiceProxy orderserviceproxy;
	

	@GetMapping("/get-viewCustomersOrder/{emailId}")
	public List<Ordered> getCustomerOrderedItems(@PathVariable("emailId") String emailId) {
		List<Ordered> order = orderserviceproxy.getCustomerOrderedItems(emailId);
		return order;
	}
	
	@GetMapping("/get-viewAllOrders")
	public List<Ordered> getOrderedItems() {
		List<Ordered> orders = orderserviceproxy.getOrderedItems();
		return orders;
	}
}
