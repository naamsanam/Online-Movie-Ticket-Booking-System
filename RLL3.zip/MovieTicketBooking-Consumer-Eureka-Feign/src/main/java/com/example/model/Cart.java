package com.example.model;

public class Cart {
	private long id;
	private int quantity;
	private float price;
	private Movie movie;

	public Cart(long id, int quantity, float price, Movie movie) {
		super();
		this.id = id;
		this.quantity = quantity;
		this.price = price;
		this.movie = movie;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

}
