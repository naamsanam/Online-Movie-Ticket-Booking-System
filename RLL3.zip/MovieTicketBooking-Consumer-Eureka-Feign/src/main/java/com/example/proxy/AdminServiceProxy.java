package com.example.proxy;

import java.util.List;

import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.server.ResponseStatusException;

import com.example.model.Admin;
import com.example.model.Login;

@FeignClient(name = "admin-service")
public interface AdminServiceProxy {
	
	 @GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
	    public List<Admin> getAllAdmins();

	    // Example endpoint to get admin by ID
	    @GetMapping(value = "/all/{adminId}", produces = MediaType.APPLICATION_JSON_VALUE)
	    public Admin getAdminById(@PathVariable("adminId") long id);
	    
	    @GetMapping(value = "/allloginusers", produces = MediaType.APPLICATION_JSON_VALUE)
	    public List<Login> getAllUsers();

}
