package com.example.proxy;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.model.Customer;

@FeignClient("customer-service")
public interface CustomerServiceProxy {
	
	@GetMapping(value = "/viewAll", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Customer> viewAllCustomers();

    @GetMapping(value = "/viewAllBy/{searchKeyword}", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Customer> viewAllCustomersBySearchKeyword(@PathVariable String searchKeyword);
}
