package com.example.proxy;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.model.Login;

@FeignClient("login-service")
public interface LoginServiceProxy {
//         
//	 @GetMapping(value = "/allusers", produces = MediaType.APPLICATION_JSON_VALUE)
//	    public List<Login> getAllUsers();
	 
	 @GetMapping(value = "/log/allusers", produces = MediaType.APPLICATION_JSON_VALUE)
	    public List<Login> getAllUsers();

//	public ResponseEntity<List<Login>> findAllUser();
	    }
