package com.example.proxy;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.server.ResponseStatusException;

import com.example.model.Movie;


@FeignClient("movie-service")
public interface MovieServiceProxy {
	
	 @GetMapping(value="/allMovies" , produces = MediaType.APPLICATION_JSON_VALUE)
	    public List<Movie> getAllMovies();

	    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	    public Movie getMovieById(@PathVariable long id);

}
