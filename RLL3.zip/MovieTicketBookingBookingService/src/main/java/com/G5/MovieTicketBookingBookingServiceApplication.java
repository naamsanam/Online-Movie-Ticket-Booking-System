package com.G5;

import java.sql.Date;
import java.text.SimpleDateFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.G5.model.Ordered;
import com.G5.repository.OrderedRepository;

@SpringBootApplication
public class MovieTicketBookingBookingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieTicketBookingBookingServiceApplication.class, args);
	}
	
	
	@Bean
	public CommandLineRunner initOrdered(OrderedRepository OrderedRepository) {
	    return args -> {
	    	
	    	 Date currDate = new Date(0, 0, 0);

	         // Format the date as a string if needed
	         SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	         String formattedDate = dateFormat.format(currDate);

	        OrderedRepository.save(new Ordered(5, 200.0f, "admin@gmail.com", currDate , 5));
	    };
    }

}
