package com.G5.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import com.G5.model.Movie;
import com.G5.service.MovieService;

import java.util.List;

@RestController
@RequestMapping("/movie")
public class MovieController {

    @Autowired
    private MovieService movieService;

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Movie>> getAllMovies() {
        List<Movie> movies = movieService.viewAllMovie();
        return ResponseEntity.ok(movies);
    }

    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Movie> getMovieById(@PathVariable int id) {
        Movie movie = movieService.getMovieById(id);
        if (movie == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Movie not found");
        }
        return ResponseEntity.ok(movie);
    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<Movie> addMovie(@RequestBody Movie movie) {
        Movie addedMovie = movieService.addNewMovie(movie);
        if (addedMovie == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Unable to add movie");
        }
        return ResponseEntity.ok(addedMovie);
    }

    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Movie> updateMovie(@PathVariable int id, @RequestBody Movie movie) {
        Movie updatedMovie = movieService.updateMovieById(movie);
        if (updatedMovie == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Unable to update movie");
        }
        return ResponseEntity.ok(updatedMovie);
    }

    @DeleteMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteMovieById(@PathVariable int id) {
        boolean deleted = movieService.deleteMovieById(id);
        if (!deleted) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Movie not found");
        }
    }

    @GetMapping(value = "/search/{keyword}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Movie>> searchMoviesByKeyword(@PathVariable String keyword) {
        List<Movie> movies = movieService.searchMovieByKeyword(keyword);
        return ResponseEntity.ok(movies);
    }

    @GetMapping(value = "/searchByAction/{actionType}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Movie>> searchMoviesByAction(@PathVariable String actionType) {
        List<Movie> movies = movieService.searchMovieByAction(actionType);
        return ResponseEntity.ok(movies);
    }
}
