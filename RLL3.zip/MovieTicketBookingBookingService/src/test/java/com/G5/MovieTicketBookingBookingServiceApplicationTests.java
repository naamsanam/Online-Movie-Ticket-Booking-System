package com.G5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieTicketBookingBookingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
