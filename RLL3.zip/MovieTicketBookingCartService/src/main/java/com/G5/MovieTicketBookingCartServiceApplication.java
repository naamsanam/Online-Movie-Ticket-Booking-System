package com.G5;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.G5.model.Cart;
import com.G5.model.Movie;
import com.G5.repository.CartRepository;
import com.G5.repository.MovieRepository;

@SpringBootApplication
public class MovieTicketBookingCartServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieTicketBookingCartServiceApplication.class, args);
	}
	
	@Bean
    public CommandLineRunner initCart(CartRepository cartRepository, MovieRepository movieRepository) {
        return args -> {
            Integer movieId = 1; // Replace with the actual movie ID
            Movie movie = movieRepository.findById(movieId).orElse(null);
            if (movie != null) {
                cartRepository.save(new Cart(100L, 2, 1000.0f, movie));
            }
        };
    }

}
