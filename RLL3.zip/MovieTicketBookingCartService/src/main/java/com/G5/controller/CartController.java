package com.G5.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.G5.model.Cart;
import com.G5.service.CartService;

@RestController
@RequestMapping("/cart") 
public class CartController {
    @Autowired
    CartService cartService;

    @PostMapping(value = "/addToCart", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Cart> addToCart(@RequestBody Cart cart, HttpSession session) {
        Cart addedCart = cartService.addMoviesToCart(cart, session);
        if (addedCart != null) {
            return ResponseEntity.status(HttpStatus.CREATED).body(addedCart);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping(value = "/viewAllCarts", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Cart>> getCartItems() {
        List<Cart> cartItems = cartService.getAllCartItems();
        if (cartItems != null) {
            return ResponseEntity.status(HttpStatus.OK).body(cartItems);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PutMapping(value = "/addInCart", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> addInCart(@RequestBody Cart cart) {
        boolean success = cartService.plusOneCartItem(cart);
        if (success) {
            return ResponseEntity.status(HttpStatus.OK).build();
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PutMapping(value = "/minusInCart", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> minusInCart(@RequestBody Cart cart) {
        boolean success = cartService.minusOneCartItem(cart);
        if (success) {
            return ResponseEntity.status(HttpStatus.OK).build();
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DeleteMapping("/deleteCart/{cId}")
    public ResponseEntity<Void> deleteCart(@PathVariable("cId") Long cId) {
        boolean success = cartService.deleteCart(cId);
        if (success) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
