package com.G5;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.G5.model.Customer;
import com.G5.repository.CustomerRepository;

@SpringBootApplication
public class MovieTicketBookingCustomerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieTicketBookingCustomerServiceApplication.class, args);
	}
	
	@Bean
    public CommandLineRunner initCustomer(CustomerRepository customerRepository) {
        return args -> {
            Customer newCustomer = new Customer("fullname", "admin@gmail.com", "admin", "9876543210");
            customerRepository.save(newCustomer);
        };
    }

}
