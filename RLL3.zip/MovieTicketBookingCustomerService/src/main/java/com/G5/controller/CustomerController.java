package com.G5.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import com.G5.model.Customer;
import com.G5.service.CustomerService;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("customer")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @PostMapping(value = "/addCustomer", produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public boolean addCustomer(@RequestBody Customer customer) {
        return customerService.addNewCustomer(customer);
    }

    @PostMapping(value = "/login", produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public boolean customerLogin(@RequestBody Map<String, String> loginCredentials) {
        String emailId = loginCredentials.get("emailId");
        String password = loginCredentials.get("password");
        return customerService.CustomerLogin(emailId, password);
    }

    @PutMapping(value = "/updateCustomer", produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public boolean updateCustomer(@RequestBody Customer customer) {
        return customerService.updateCustomer(customer);
    }

    @DeleteMapping(value = "/deleteCustomer/{emailId}")
    public boolean deleteCustomer(@PathVariable String emailId) {
        return customerService.deleteCustomer(emailId);
    }

    @GetMapping(value = "/viewAll", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Customer> viewAllCustomers() {
        return customerService.viewAllCustomer();
    }

    @GetMapping(value = "/viewAllBy/{searchKeyword}", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Customer> viewAllCustomersBySearchKeyword(@PathVariable String searchKeyword) {
        return customerService.viewSearchKeywordCustomer(searchKeyword);
    }

    @GetMapping(value = "/viewBy/{emailId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Optional<Customer> viewCustomerByEmailId(@PathVariable String emailId) {
        return customerService.searchCustomerByEmail(emailId);
    }
}
