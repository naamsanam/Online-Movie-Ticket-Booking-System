package com.G5;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;

import com.G5.model.Login;
import com.G5.repository.LoginRepository;

@EnableEurekaClient
@SpringBootApplication
public class MovieTicketBookingLoginServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieTicketBookingLoginServiceApplication.class, args);
	}
	
	@Bean
    public CommandLineRunner initLogin(LoginRepository loginRepository) {
        return args -> {
            // Initialize login data here, for example:
            loginRepository.save(new Login("user@gmail.com", "password", "user"));
        };
    }

}
