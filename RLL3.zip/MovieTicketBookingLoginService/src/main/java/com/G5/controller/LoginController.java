package com.G5.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.G5.model.Login;
import com.G5.service.LoginService;

@RestController
@RequestMapping("/log") // Define your base URL
public class LoginController {

    @Autowired
    private LoginService loginService;

    @PostMapping(value = "/signin", produces = MediaType.TEXT_PLAIN_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> signIn(@RequestBody Login login) {
        String result = loginService.signIn(login);
        if (result.startsWith("User")) {
            return ResponseEntity.ok(result);
        } else if (result.startsWith("Admin")) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        }
    }

    @PostMapping(value = "/signup", produces = MediaType.TEXT_PLAIN_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> signUp(@RequestBody Login login) {
        String result = loginService.signUp(login);
        if (result.equals("Account created successfully")) {
            return ResponseEntity.status(HttpStatus.CREATED).body(result);
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }
    }

    @PostMapping(value = "/changepassword", produces = MediaType.TEXT_PLAIN_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> changePassword(@RequestBody Login login) {
        String result = loginService.changePassword(login);
        if (result.equals("password changed successfully")) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }
    }

    @DeleteMapping(value = "/deleteuser/{emailid}")
    public ResponseEntity<String> deleteUser(@PathVariable String emailid) {
        String result = loginService.deleteusers(emailid);
        if (result.equals("User deleted successfully")) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result);
        }
    }

    @GetMapping(value = "/allusers", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Login>> getAllUsers() {
        List<Login> users = loginService.findAllUser();
        return ResponseEntity.ok(users);
    }
}
